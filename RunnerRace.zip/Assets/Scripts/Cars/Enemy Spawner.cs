using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject[] carsPrefeb;
    public Transform[] xPositions;

    private int RandomChance;
    int chance = 1;

    private void Start()
    {
        RandomChance = Random.Range(1, 5);
        UIManager.instance.SetTotalPositions(RandomChance+1);
        foreach (var xpos in xPositions)
        {
            CarsSpawn(xpos);
        }
    }

    private void CarsSpawn(Transform xpos)
    {
        if (chance <= RandomChance)
        {
            int rand = Random.Range(1, carsPrefeb.Length);
            Vector3 spawnPosition = new Vector3(xpos.position.x, xpos.position.y, xpos.position.z);
            Instantiate(carsPrefeb[rand], spawnPosition, Quaternion.identity, transform);
            chance++;
        }
    }
}
