# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2022-11-20

### Added
 - Initial release
