﻿using System;
using UnityEngine;

namespace CollisionBear.PreviewObjectPicker
{
    public class PreviewFieldAttribute : PropertyAttribute
    {
        public PreviewFieldAttribute() { }
    }
}