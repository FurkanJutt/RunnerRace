using UnityEngine;

namespace CollisionBear.PreviewObjectPicker.Examples {
    // Test class
    // Its only purpose is to be shown how the PreviewField can filter out prefabs based on MonoBehaviour 
    // derived classes
    public class TestBlocker : MonoBehaviour { }
}