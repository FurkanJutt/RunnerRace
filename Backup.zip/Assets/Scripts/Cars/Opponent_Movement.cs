using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Opponent_Movement : MonoBehaviour
{
    private float speed = 2f;
    public float minSpeed = 2f;
    public float maxSpeed = 8f;

    private Transform respawnPosition;
    private Transform bottomBarrier;
    private Transform topBarrier;

    [SerializeField] private Vector3 tempPos;

    [Header("Sounds")]
    public AudioClip engineStart;
    public AudioClip hitClip;
    public AudioClip waterClip;
    public AudioClip grassClip;

    private void Start()
    {
        speed = Random.Range(minSpeed, maxSpeed);
        //respawnPosition = GameObject.FindWithTag("SpawnPoint").GetComponent<Transform>();
        topBarrier = UIManager.instance.topBarrier;
        bottomBarrier = UIManager.instance.bottomBarrier;
    }

    private void Update()
    {
        VerticalMovement();
        Clamp();
    }

    private void VerticalMovement()
    {
        // Move the opponent vertically
        transform.position += new Vector3(0, speed * Time.deltaTime, 0);

        //if (transform.rotation.z != 90)
        //{
        //    transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0, 0, 0), 10f * Time.deltaTime);
        //}
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Opponent"))
        {
            SoundManager.instance.PlaySoundFX(hitClip, 0.9f);
            GameDataManager.Instance.EndGame();
        }
        else if (other.gameObject.CompareTag("Player"))
        {
            Vector2 playerCenter = transform.position;
            Vector2 opponentCenter = other.transform.position;
            Vector2 collisionDirection = (playerCenter - opponentCenter).normalized;

            SoundManager.instance.PlaySoundFX(hitClip, 0.9f);

            Rigidbody2D opponentRigidbody = other.gameObject.GetComponent<Rigidbody2D>();
            if (opponentRigidbody != null)
            {
                // Adjust the bounce force based on collision direction
                float bounceForce = 1f; // You can adjust this value as needed

                // Apply a force to the player in the collision direction
                opponentRigidbody.AddForce(-collisionDirection * bounceForce, ForceMode2D.Impulse);


                // Apply a force to the opponent in the opposite direction
                opponentRigidbody.AddForce(-collisionDirection * bounceForce, ForceMode2D.Impulse);
            }
        }

        //if (other.gameObject.CompareTag("Opponent") || other.gameObject.CompareTag("OtherCar"))
        //{
        //    Vector2 playerCenter = transform.position;
        //    Vector2 opponentCenter = other.transform.position;
        //    Vector2 collisionDirection = (playerCenter - opponentCenter).normalized;

        //    Rigidbody2D opponentRigidbody = other.gameObject.GetComponent<Rigidbody2D>();
        //    if (opponentRigidbody != null)
        //    {
        //        float bounceForce = 1f;
        //        opponentRigidbody.AddForce(-collisionDirection * bounceForce, ForceMode2D.Impulse);
        //        opponentRigidbody.AddForce(-collisionDirection * bounceForce, ForceMode2D.Impulse);
        //    }
        //}

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        //if (other.CompareTag("Timer"))
        //{
        //    other.transform.parent.gameObject.SetActive(false);
        //}
        /*else*/ if (other.CompareTag("Coin"))
        {
            other.transform.parent.gameObject.SetActive(false);
        }
        if (other.gameObject.CompareTag("Water"))
        {
            //tempPos = respawnPosition.position;
            SoundManager.instance.PlaySoundFX(waterClip, 0.2f);
            //StartCoroutine(RespawnAfterDelay(1f));
            GameDataManager.Instance.EndGame();
        }
        else if (other.gameObject.CompareTag("Grass"))
        {
            //tempPos = respawnPosition.position;
            SoundManager.instance.PlaySoundFX(grassClip, 0.2f);
            //StartCoroutine(RespawnAfterDelay(1f));
            GameDataManager.Instance.EndGame();
        }
    }

    private void Clamp()
    {
        //Unity Inbuilt Feature
        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, -2.20f, 2.20f);
        pos.y = Mathf.Clamp(pos.y, bottomBarrier.position.y, topBarrier.position.y);
        // pos.y = Mathf.Clamp(pos.y, -3.8f, 3.8f);
        transform.position = pos;
    }

    private IEnumerator RespawnAfterDelay(float delay)
    {
        yield return new WaitForSeconds(0.3f);

        float tempSpeed = speed;
        speed = 0f;

        yield return new WaitForSeconds(delay);

        SoundManager.instance.PlaySoundFX(engineStart, 0.2f);

        transform.position = tempPos;
        transform.rotation = Quaternion.Euler(0, 0, 0);
        speed = tempSpeed;
    }
}
